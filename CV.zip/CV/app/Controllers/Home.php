<?php

namespace App\Controllers;

use App\Models\RafModel;
use App\Models\EduModel;


class Home extends BaseController
{
    public function index()
    {
        $raf = new RafModel();
        $edu = new EduModel();

        $data = [
            'title' => 'CV RAF',
            'raf'  =>$raf->findAll()[0],
            'edu'=>$edu->findAll(),
        ];
        return view('home', $data);
    }
}
